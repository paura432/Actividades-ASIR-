﻿Remove-ADOrganizationalUnit -identity "OU=PracticaPWS,DC=PAU,DC=LOCAL" -Recursive -Confirm:$false
